const db = require('../config/db');
const redis = require('../config/redis');
const authMiddleware = require('../middleware/auth');

exports.getReferralStats = [authMiddleware, async (req, res) => {
  try {
    const cacheKey = `referral_stats_${req.user.id}`;
    console.log('Checking Redis cache for stats...');
    const cachedStats = await redis.get(cacheKey);

    if (cachedStats) {
      const responseData = JSON.parse(cachedStats);
      res.json(responseData);
      console.log('Response sent from cache:', responseData);
      return;
    }

    console.log('Fetching referral stats from DB...');
    const [stats] = await db.query(
      'SELECT COUNT(*) as successful_referrals FROM referrals WHERE referrer_id = ? AND status = "successful"',
      [req.user.id]
    );
    console.log('DB query result:', stats);
    const result = { successfulReferrals: stats[0].successful_referrals };

    console.log('Caching result in Redis...');
    await redis.setEx(cacheKey, 3600, JSON.stringify(result));
    res.json(result);
    console.log('Response sent:', result);
  } catch (err) {
    console.error('Referral stats error:', err);
    res.status(500).json({ message: 'Server error' });
  }
}];