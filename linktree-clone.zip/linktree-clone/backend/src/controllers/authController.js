const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/db');
const redis = require('../config/redis');
const Joi = require('joi');
const { sendResetEmail } = require('../services/emailService');

const registerSchema = Joi.object({
  email: Joi.string().email().required(),
  username: Joi.string().min(3).max(50).required(),
  password: Joi.string().min(8).required(),
  referralCode: Joi.string().allow('').optional(),
});

const loginSchema = Joi.object({
  identifier: Joi.string().required(),
  password: Joi.string().required(),
});

exports.register = async (req, res) => {
  const { error } = registerSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  const { email, username, password, referralCode } = req.body;

  try {
    console.log('Checking for existing user...');
    const [existingUser] = await db.query('SELECT * FROM users WHERE email = ? OR username = ?', [email, username]);
    console.log('Existing user check result:', existingUser);
    if (existingUser.length > 0) return res.status(400).json({ message: 'Email or username already in use' });

    console.log('Hashing password...');
    const passwordHash = await bcrypt.hash(password, 10);
    const referralCodeGenerated = uuidv4().slice(0, 8);
    let referredBy = null;

    if (referralCode && referralCode.trim() !== '') {
      console.log('Validating referral code...');
      const [referrer] = await db.query('SELECT id FROM users WHERE referral_code = ?', [referralCode]);
      console.log('Referrer query result:', referrer);
      if (referrer.length === 0) return res.status(400).json({ message: 'Invalid referral code' });
      referredBy = referrer[0].id;
    }

    const userId = uuidv4();
    console.log('Inserting new user...');
    await db.query(
      'INSERT INTO users (id, username, email, password_hash, referral_code, referred_by) VALUES (?, ?, ?, ?, ?, ?)',
      [userId, username, email, passwordHash, referralCodeGenerated, referredBy]
    );

    if (referredBy) {
      console.log('Recording referral...');
      await db.query(
        'INSERT INTO referrals (id, referrer_id, referred_user_id, status) VALUES (?, ?, ?, ?)', 
        [uuidv4(), referredBy, userId, 'successful']
      );
    }

    console.log('Generating JWT...');
    const token = jwt.sign({ id: userId }, process.env.JWT_SECRET, { expiresIn: '1h' });
    const responseData = { message: 'User registered', referralLink: `${process.env.BASE_URL}/register?referral=${referralCodeGenerated}` };
    res.cookie('token', token, { httpOnly: true });
    res.status(201).json(responseData);
    console.log('Response sent:', responseData);
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.login = async (req, res) => {
  const { error } = loginSchema.validate(req.body);
  if (error) return res.status(400).json({ message: error.details[0].message });

  const { identifier, password } = req.body;

  try {
    console.log('Checking user credentials...');
    const [user] = await db.query('SELECT * FROM users WHERE email = ? OR username = ?', [identifier, identifier]);
    console.log('User query result:', user);
    if (user.length === 0) return res.status(400).json({ message: 'Invalid credentials' });

    console.log('Verifying password...');
    const validPassword = await bcrypt.compare(password, user[0].password_hash);
    if (!validPassword) return res.status(400).json({ message: 'Invalid credentials' });

    console.log('Generating JWT...');
    const token = jwt.sign({ id: user[0].id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    const responseData = { message: 'Logged in successfully' };
    res.cookie('token', token, { httpOnly: true });
    res.json(responseData);
    console.log('Response sent:', responseData);
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.forgotPassword = async (req, res) => {
  const { email } = req.body;

  try {
    console.log('Checking user for password reset...');
    const [user] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    console.log('User query result:', user);
    if (user.length === 0) return res.status(404).json({ message: 'User not found' });

    console.log('Generating reset token...');
    const resetToken = jwt.sign({ id: user[0].id }, process.env.JWT_SECRET, { expiresIn: '15m' });
    console.log('Sending reset email...');
    await sendResetEmail(email, resetToken);

    const responseData = { message: 'Password reset link sent to email' };
    res.json(responseData);
    console.log('Response sent:', responseData);
  } catch (err) {
    console.error('Forgot password error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};