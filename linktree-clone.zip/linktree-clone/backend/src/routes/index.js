const express = require('express');
const authController = require('../controllers/authController');
const referralController = require('../controllers/referralController');

const router = express.Router();

router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/forgot-password', authController.forgotPassword);
router.get('/referral-stats', referralController.getReferralStats);

module.exports = router;