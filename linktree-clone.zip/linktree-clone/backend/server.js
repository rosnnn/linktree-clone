const express = require('express');
const cookieParser = require('cookie-parser');
const dotenv = require('dotenv');
const routes = require('./src/routes');
const rateLimit = require('express-rate-limit');
const cors = require('cors');

dotenv.config();

// Log environment variables to verify
console.log('DATABASE_HOST:', process.env.DATABASE_HOST);
console.log('DATABASE_USER:', process.env.DATABASE_USER);
console.log('DATABASE_PASSWORD:', process.env.DATABASE_PASSWORD);
console.log('DATABASE_NAME:', process.env.DATABASE_NAME);

const app = express();

// Enable CORS
app.use(cors({
  origin: 'http://127.0.0.1:8080',
  credentials: true,
}));

// Log request details including IP
app.use((req, res, next) => {
  const clientIp = req.ip || req.connection.remoteAddress;
  console.log(`Received ${req.method} request to ${req.url} from IP: ${clientIp}`);
  next();
});

app.use(express.json());
app.use(cookieParser());
app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Max 100 requests per window
  })
);

app.use('/api', routes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));