const API_URL = 'http://localhost:3000/api';

async function register() {
  const username = document.getElementById('reg-username').value;
  const email = document.getElementById('reg-email').value;
  const password = document.getElementById('reg-password').value;
  const referralCode = document.getElementById('reg-referral').value;

  const response = await fetch(`${API_URL}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password, referralCode }),
    credentials: 'include',
  });

  const data = await response.json();
  document.getElementById('reg-message').innerText = data.message || data.referralLink;
  if (response.ok) showReferralStats();
}

async function login() {
  const identifier = document.getElementById('login-identifier').value;
  const password = document.getElementById('login-password').value;

  const response = await fetch(`${API_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier, password }),
    credentials: 'include',
  });

  const data = await response.json();
  document.getElementById('login-message').innerText = data.message;
  if (response.ok) showReferralStats();
}

async function forgotPassword() {
  const email = document.getElementById('forgot-email').value;

  const response = await fetch(`${API_URL}/forgot-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email }),
    credentials: 'include',
  });

  const data = await response.json();
  document.getElementById('forgot-message').innerText = data.message;
}

async function showReferralStats() {
  const response = await fetch(`${API_URL}/referral-stats`, {
    credentials: 'include',
  });

  if (response.ok) {
    const data = await response.json();
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('forgot-password-form').style.display = 'none';
    document.getElementById('referral-stats').style.display = 'block';
    document.getElementById('stats-message').innerText = `Successful Referrals: ${data.successfulReferrals}`;
  }
}

function logout() {
  document.cookie = 'token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
  location.reload();
}