Hey there! This is my take on a LinkTree/Bento.me-style app—lets users sign up, log in, share referral codes, and reset passwords if they forget ‘em. Built it from scratch.

#Assignment Check
->The assignment asked for:

✔ User Registration & Authentication: Yep—signup with email/username/password, login, JWT tokens, password reset with email. 
✔ Referral System: Covered—unique referral codes, tracking successful sign-ups, stats visible on login. 
✔ Password Management: Done—secure hashing (bcrypt), reset via email with tokens.
✔ API Endpoints: All there—/api/register, /api/login, /api/forgot-password, /api/referral-stats.
✔ Data Validation & Error Handling: Joi validates inputs, clear error messages (e.g., "Invalid credentials").
✔ Database Design: created database in mysql workbench, Matches—users and referrals tables with proper relationships.
✔ Security: JWT in HttpOnly cookies, rate limiting, bcrypt hashing.
✔ Session Management: JWT handles sessions securely.
✔ Performance & Scalability: Redis caching for referral stats, ready for scaling.
✔ Testing: I’ve tested it locally—works fine now!
Everything’s covered—the referral fix, design tweaks, and all requirements are in place.


#What It Does
Sign up with a username, email, and password (referral code’s optional #can only be used after first login, the referal code generates and can be used further).
Log in with those creds to see how many folks you’ve referred.
Share a referral code with friends—when they use it, your stats go up.
Forgot your password? Pop in your email and get a reset link.


#Stuff You Need
Node.js (latest should work, I used a recent version).
MySQL (I ran it through Workbench).
Redis (just the basic install, uses port 6379).
Chrome to check it out.


#How to Get It Rolling
Grab the Files:
Unzip this wherever you want (say, a project folder).
Set Up the Backend:
In the .env file replace with your keys and id's and keep in mind after = don't leave any spaces,(i have already checked with mine and it was like a hot knife going through butter, smothhhh!)
Open a terminal, go to backend/.
Run npm install to grab the bits it needs.
Start it with node server.js—you’ll see it’s live on port 3000.
Database Setup:
Fire up MySQL Workbench, log in with your root account.
Run this to set up the tables:
text
Wrap
Copy
CREATE DATABASE myprojectdb;
USE myprojectdb;
CREATE TABLE users (
    id VARCHAR(36) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    referral_code VARCHAR(10) UNIQUE NOT NULL,
    referred_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (referred_by) REFERENCES users(id)
);
CREATE TABLE referrals (
    id VARCHAR(36) PRIMARY KEY,
    referrer_id VARCHAR(36) NOT NULL,
    referred_user_id VARCHAR(36) NOT NULL,
    date_referred TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'successful') DEFAULT 'pending',
    FOREIGN KEY (referrer_id) REFERENCES users(id),
    FOREIGN KEY (referred_user_id) REFERENCES users(id)
);
Redis:
Start Redis in another terminal (like redis-server if you’ve got it installed).
Frontend:
In a new terminal, go to frontend/.
Run npx http-server, then hit http://127.0.0.1:8080 in Chrome.


#How to Use It
Sign Up: Fill in username, email, password—referral code’s up to you. You’ll get a link to share.
Log In: Use your email or username and password, see your referral count.
Referral: Give your code to someone. They sign up with it, your count ticks up.
Reset Password: Enter your email, check your inbox (needs a real email to work).


#Note for You
Backend logs show what’s happening—check the terminal for sign-ups or logins.
To start fresh, clear the tables in Workbench with:
text
Wrap
Copy
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE users;
TRUNCATE TABLE referrals;
SET FOREIGN_KEY_CHECKS = 1;

